/*---------------------------------------------------------------------------*\
License

    This is free software: you can redistribute it and/or modify it
    under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This code is distributed in the hope that it will be useful, but WITHOUT
    ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
    FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
    for more details.

    You should have received a copy of the GNU General Public License
    along with this code. If not, see <http://www.gnu.org/licenses/>.

    Copyright (C) 2018- Mathias Vångö, JKU Linz, Austria

\*---------------------------------------------------------------------------*/

#include "error.H"

#include "surfaceTensionForce1.H"
#include "addToRunTimeSelectionTable.H"

// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * //

namespace Foam
{

// * * * * * * * * * * * * * * Static Data Members * * * * * * * * * * * * * //

defineTypeNameAndDebug(surfaceTensionForce1, 0);

addToRunTimeSelectionTable
(
    forceModel,
    surfaceTensionForce1,
    dictionary
);


// * * * * * * * * * * * * * * * * Constructors  * * * * * * * * * * * * * * //

// Construct from components
surfaceTensionForce1::surfaceTensionForce1
(
    const dictionary& dict,
    cfdemCloud& sm
)
:
    forceModel(dict,sm),
    propsDict_(dict.subDict(typeName + "Props")),
    stfFieldName_(propsDict_.lookupOrDefault<word>("stfFieldName", "surfaceTensionForce1")),
    stf_(sm.mesh().lookupObject<surfaceScalarField> (stfFieldName_)),
    TFieldName_(propsDict_.lookupOrDefault<word>("TFieldName", "surfaceTensionForce1")),
    T_(sm.mesh().lookupObject<volScalarField> (TFieldName_)),
    Lc_1(readScalar(propsDict_.lookup("Lc1"))),
    Tli(readScalar(propsDict_.lookup("Tli"))),
    Ls_(readScalar(propsDict_.lookup("Ls"))),
    nnFieldName_(propsDict_.lookupOrDefault<word>("nnFieldName", "surfaceTensionForce1")),
    nn(sm.mesh().lookupObject<volVectorField> (nnFieldName_))

{


    // init force sub model
    setForceSubModels(propsDict_);

    // define switches which can be read from dict
    forceSubM(0).setSwitchesList(0,true); // activate treatExplicit switch

    // read those switches defined above, if provided in dict
    forceSubM(0).readSwitches();

    Info << "check if interpolation really works - use directly interpolationCellPoint<vector> ???" << endl;
    particleCloud_.checkCG(false);
}


// * * * * * * * * * * * * * * * * Destructor  * * * * * * * * * * * * * * * //

surfaceTensionForce1::~surfaceTensionForce1()
{}


// * * * * * * * * * * * * * * * Member Functions  * * * * * * * * * * * * * //

void surfaceTensionForce1::setForce() const
{
scalar sumUCoefficient(0); scalar distance(0);
 scalar coefficient(0);scalar sumVol(0);
scalar ds;vector position;  
dimensionedScalar T1("T1",dimensionSet(0,0,0,1.0,0,0,0),1.0);
volScalarField TT=T_/T1;
volVectorField reconstructedStf = fvc::reconstruct(stf_*particleCloud_.mesh().magSf());
    for(int index = 0;index <  particleCloud_.numberOfParticles(); ++index)
    {
        //if(mask[index][0])
        //{
            // definition of spherical particle
            label cellI = particleCloud_.cellIDs()[index][0];
            scalar Vp = particleCloud_.particleVolume(index);
            ds = 2*particleCloud_.radius(index); 
            coefficient=0;   distance=0;   sumUCoefficient=0; sumVol=0;  
  
    vector surfaceTensionForce1p = Foam::vector(0,0,0);
            if(cellI >-1.0) // particle found on proc domain
            {   position = particleCloud_.position(index);
                scalar sumco=0; sumUCoefficient=0;

forAll(particleCloud_.mesh().C(),celli)
          {  distance=mag(particleCloud_.mesh().C()[celli]-particleCloud_.position(index));
          if (distance<=Ls_*ds )
             {  coefficient=exp(-distance*distance/(2.0*Lc_1*Lc_1*ds*ds));
                 sumUCoefficient=sumUCoefficient+coefficient;
             
                surfaceTensionForce1p =  surfaceTensionForce1p -coefficient * pow(pos(TT[cellI]-Tli),10.0)*mag(reconstructedStf[cellI])*nn[cellI];
}
            
      
          }
 surfaceTensionForce1p= surfaceTensionForce1p*Vp/sumUCoefficient;
               // write particle based data to global array
               forceSubM(0).partToArray(index,surfaceTensionForce1p,vector::zero);

            } // end if particle found on proc domain
        //}// end if in mask
    }// end loop particles
}


// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * //

} // End namespace Foam

// ************************************************************************* //
