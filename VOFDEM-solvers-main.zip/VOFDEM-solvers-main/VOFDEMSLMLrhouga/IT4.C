/*---------------------------------------------------------------------------*\
    CFDEMcoupling - Open Source CFD-DEM coupling

    CFDEMcoupling is part of the CFDEMproject
    www.cfdem.com
                                Christoph Goniva, christoph.goniva@cfdem.com
                                Copyright (C) 1991-2009 OpenCFD Ltd.
                                Copyright (C) 2009-2012 JKU, Linz
                                Copyright (C) 2012-     DCS Computing GmbH,Linz
-------------------------------------------------------------------------------
License
    This file is part of CFDEMcoupling.

    CFDEMcoupling is free software: you can redistribute it and/or modify it
    under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    CFDEMcoupling is distributed in the hope that it will be useful, but WITHOUT
    ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
    FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
    for more details.

    You should have received a copy of the GNU General Public License
    along with CFDEMcoupling.  If not, see <http://www.gnu.org/licenses/>.

Application
    cfdemSolverpimple

Description
    Transient solver for incompressible flow.
    Turbulence modelling is generic, i.e. laminar, RAS or LES may be selected.
    The code is an evolution of the solver pimpleFoam in OpenFOAM(R) 1.6,
    where additional functionality for CFD-DEM coupling is added.
\*---------------------------------------------------------------------------*/
#include "isoAdvection.H"
#include "fvCFD.H"
#include "CMULES.H"/////////1
#include "EulerDdtScheme.H"
#include "localEulerDdtScheme.H"
#include "CrankNicolsonDdtScheme.H"
#include "subCycle.H"
#include "immiscibleIncompressibleTwoPhaseMixture.H"
#include "CorrectPhi.H"
#include "fvcSmooth.H"   ///////////////1
//#include "singlePhaseTransportModel.H"
#include "pimpleControl.H"///////////2
#include "pressureControl.H"
#include "bound.H"
#include "radiationModel.H"
#include "OFversion.H"
#if defined(version30)
    #include "turbulentTransportModel.H"
    #include "pimpleControl.H"
#else
    #include "turbulenceModel.H"
#endif
#if defined(versionv1606plus) || defined(version40)
    #include "fvOptions.H"
#else
    #include "fvIOoptionList.H"
#endif
#include "fixedFluxPressureFvPatchScalarField.H"
#include "cfdemCloud.H"

#if defined(anisotropicRotation)
    #include "cfdemCloudRotation.H"
#endif
#if defined(superquadrics_flag)
    #include "cfdemCloudRotationSuperquadric.H"
#endif
#include "implicitCouple.H"
#include "clockModel.H"
#include "smoothingModel.H"
#include "forceModel.H"


// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * //

int main(int argc, char *argv[])
{ 
    #include "postProcess.H"
    #include "setRootCase.H"
    #include "createTime.H"
    #include "createMesh.H"
    #include "createControl.H"
  //  #if defined(version30)
  //      pimpleControl pimple(mesh);
    #include "createTimeControls.H"
   // #endif
    #include "createFields.H"
    #include "createAlphaFluxes.H"
    #include "createFvOptions.H"
    #include "initContinuityErrs.H"
    turbulence->validate();
   if (!LTS)
    {
        #include "readTimeControls.H"
        #include "CourantNo.H"
        #include "setInitialDeltaT.H"
    }

    // create cfdemCloud
   // #include "readGravitationalAcceleration.H"
    #include "checkImCoupleM.H"
    #if defined(anisotropicRotation)
        cfdemCloudRotation particleCloud(mesh);
    #elif defined(superquadrics_flag)
        cfdemCloudRotationSuperquadric particleCloud(mesh);
    #else
        cfdemCloud particleCloud(mesh);
    #endif
    #include "checkModelType.H"

    // * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * //
    Info<< "\nStarting time loop\n" << endl;
    while (runTime.loop())
    {
       #include "readTimeControls.H"
        Info<< "Time = " << runTime.timeName() << nl << endl;
       if (LTS)
        {
            #include "setRDeltaT.H"
        }
        else
        { 
           
            #include "CourantNo.H"
            #include "alphaCourantNo.H"
            #include "setDeltaT.H"
        }
/*    
        forAll(U.boundaryField(),patchi)
     {  if(U.boundaryField()[patchi].patch().name()=="up")
        {
         forAll(U.boundaryFieldRef()[patchi], facei)
         { 
          vector x=mesh.Cf().boundaryField()[patchi][facei];// Pout<<"    x="<<x;
          if(mag(x)>=0.0045 && mag(x)<0.006)
{   
          U.boundaryFieldRef()[patchi][facei]=-0.41818*x/mag(x)+vector(0,0,-0.90836);
}
         }
        }
       
     }

*/

        // do particle stuff
        particleCloud.clockM().start(1,"Global");
        particleCloud.clockM().start(2,"Coupling");
        bool hasEvolved = particleCloud.evolve(voidfraction,Us,U);

        if(hasEvolved)
        {
            particleCloud.smoothingM().smoothenAbsolutField(particleCloud.forceM(0).impParticleForces());
        }
    
        Ksl = particleCloud.momCoupleM(particleCloud.registryM().getProperty("implicitCouple_index")).impMomSource();
        Ksl.correctBoundaryConditions();
        
        surfaceScalarField voidfractionf = fvc::interpolate(voidfraction);
        //rhoPhi = fvc::interpolate(rho)*phi;
       // rhoPhi=fvc::interpolate(rho)*phi;
        //Force Checks
        rhoPhi=linearInterpolate(U*voidfraction*rho) & mesh.Sf();
        phi=linearInterpolate(U*voidfraction) & mesh.Sf();
         //particleCloud.calcVelocityCorrection2(p_rgh,rho,U,T,Tli.value());
        #include "forceCheckIm.H"

        #include "solverDebugInfo.H"
        particleCloud.clockM().stop("Coupling");

        particleCloud.clockM().start(26,"Flow");
        volScalarField U1=U&vector(1,0,0);volScalarField U2=U&vector(0,1,0); volScalarField U3=U&vector(0,0,1);
        particleCloud.forceM(1).manipulateScalarField(Tsource);
        particleCloud.forceM(1).manipulateScalarField2(alpha1);
        particleCloud.forceM(1).manipulateU1(U1);
        particleCloud.forceM(1).manipulateU2(U2);
        particleCloud.forceM(1).manipulateU3(U3);
        U=U1*vector(1,0,0)+U2*vector(0,1,0)+U3*vector(0,0,1);
        particleCloud.forceM(1).manipulateT(T);
        Tsource.correctBoundaryConditions();
        particleCloud.forceM(1).commToDEM();

        mmu=alpha1*muw + alpha2*mua;
        volScalarField voidrho = rho * voidfraction;
        dimensionedScalar m1("m1",dimensionSet(1,-1,-1,0,0,0,0),1.0);
        dimensionedScalar T1("T1",dimensionSet(0,0,0,1.0,0,0,0),1.0);
        dimensionedScalar t1("t1",dimensionSet(0,0,1,0.0,0,0,0),1.0);
        dimensionedScalar D1("D1",dimensionSet(1,-3,-1,0,0,0,0),1.0);
        Cpw=(Cs0+Cs1*T+Cs2*T*T)*0.5*(1.0-erf(4*(T/T1-Tli)/(Tli-Tso)))+(Cl0+Cl1*T+Cl2*T*T)*0.5*(erf(4*(T/T1-Tli)/(Tli-Tso))+1.0)+pos(T/T1-Tso.value())*pos(Tli.value()-T/T1)*LL/(T1*(Tli-Tso));
        kw=(ks0+ks1*T+ks2*T*T)*0.5*(1.0-erf(4*(T/T1-Tli)/(Tli-Tso)))+(kl0+kl1*T+kl2*T*T)*0.5*(erf(4*(T/T1-Tli)/(Tli-Tso))+1.0);
        Cp=alpha1*Cpw+(1.0-alpha1)*Cpa;
        kk=alpha1*kw+(1.0-alpha1)*ka;
        volVectorField  ga=fvc::grad(alpha1);
        dimensionedScalar UU1("UU1",dimensionSet(0,1.0,-1.0,0,0,0,0),1.0);
         dimensionedScalar h1("h1",dimensionSet(1, 0, -3, -1, 0, 0, 0),1.0);
        n=-ga/(1e-5/s1+mag(ga)); 
        n=n/(1e-5+mag(n));
         volScalarField pls=n & vector(0,0,1.0);      
        if(particleCloud.solveFlow())
        {
        hc=pos((Tv-T)/T1)*0.332*ka*0.888*sqrt(Rl*rho2*sqrt(RR*T/(2.0*3.1415926*M))*exp(-M*lv/(RR*T))/mua)/Rl; 
        volScalarField hh=hc/h1;
        forAll(mesh.C(),cci)
         {    if(hh[cci]>=hf.value()) hh[cci]=hf.value();         
         }
        hc=hh*h1;
H=2.0*Rl;
H=2.0*Rl*0.816*1.37*Hc*beta*Pl/(Rl*(Tv-Tref+(LL+lv)/(Cl0+Cl1*T1*Tli+Cl2*Tli*Tli*T1*T1))*sqrt(3.1415926*Rl*mag(vl)*(kl0+kl1*Tli*T1+kl2*Tli*Tli*T1*T1)*(Cl0+Cl1*Tli*T1+Cl2*Tli*Tli*T1*T1)*rho1/t1));
W=2.0*Rl*sqrt(log(H/(2.0*Rl*0.816)));
float z0=0.0; float zmin=0.0;float dis=0.0;float dis2=0.0;float xmin=0.0;     

        forAll(T,celli)
        {  dis=mesh.C()[celli].component(0)-(x0.value()+vl.value()*runTime.value()-0.5*Rl.value());//
           dis2=mesh.C()[celli].component(0)-(x0.value()+vl.value()*runTime.value()-1.5*Rl.value());//

           if(dis<=0 && dis2>=0)
               { 
               float TT;  TT=scalar(T[celli]);
               if(TT>=Tso.value())
                    {  z0=mesh.C()[celli].component(2);
                    if(z0<=zmin) {zmin=z0;xmin=mesh.C()[celli].component(0);}
                    } 
               }
        }
H=max(Rl.value(),-zmin)*s1;
#include "TEqn.H"
  volScalarField TT=T/T1;
         forAll(mesh.C(),ci)
         {    if(TT[ci]>=Tv.value()  && alpha1[ci]>alpha0.value()) TT[ci]=Tv.value(); 
              if (TT[ci]>=KK.value()*Tv.value()) TT[ci]=KK.value()*Tv.value(); 
              if(TT[ci]<=0.95*Tref.value()) TT[ci]=0.95*Tref.value(); 
            //  if(gaf[ci]<=0.1*mm)  {alpha1[ci]=aa[ci];}
              //if(alpha1[ci]>=voidfraction[ci]) {alpha1[ci]=1.0; alpha2[ci]=0;}          
         }
         T=TT*T1;
         volScalarField  gaf=mag(fvc::grad(alpha1))*s1;
         double mm=max(gaf).value();
         volScalarField aa=alpha1;
 
         muw=pos(Tli-T/T1)*m1*exp(-C1*tanh((4.0/(log(Tli)-log(Tso)))*(log(T/T1)-0.5*(log(Tso)+log(Tli))))+C1+log(muli)) +pos(T/T1-Tli)*muli*m1*sqrt(Tli*T1/T)*exp(B*(Tli*T1/T-1.0));
 
         mmu=alpha1*muw+(1-alpha1)*mua;
         muwafa=0.5*(1+tanh(4.0*(T/T1-0.5*Tso-0.5*Tli)/(Tli-Tso)));
 hc=pos((Tv-T)/T1)*0.332*ka*0.888*sqrt(Rl*rho2*sqrt(RR*T/(2.0*3.1415926*M))*exp(-M*lv/(RR*T))/mua)/Rl; 
  
 #include "alphaControls.H"
 
                #include "alphaEqnSubCycle.H"
         
         DC=pos(alpha1-0.0001)*pos(alpha1-0.0001)*Dc*pow(1.0-muwafa,2.0)/(pow(muwafa,3.0)+Dcs);
         mixture.correct(); 
v=(1.0-alpha1)*pos(gaf-0.1)*sqrt(RR*T/(2.0*3.1415926*M))*exp(-M*LL/(RR*T))*exp(-2*(pow((mesh.C().component(0)-x0-vl*runTime.value()),2)+pow((mesh.C().component(1)-y0),2))/(Rl*Rl));
 // volScalarField Dcdc=DC/D1;
// volVectorField U0=U/UU1;
//forAll(mesh.C(),ci)
  //       {    if(Dcdc[ci]>=100.0) {U0[ci] = Ux.value()*vector(1.0,0,0);}         
    //     }
      //   U=U0*UU1;         
         voidrho = rho * voidfraction;
     
             while (pimple.loop())
            {
                #include "UEqn.H"
              
                

                // --- Pressure corrector loop
                while (pimple.correct())
                {
                    #include "pEqn.H"
                }

                if (pimple.turbCorr())
                {
                    turbulence->correct();
                }
            }
            turbulence->correct();
        }// end solveFlow
        else
        {
            Info << "skipping flow solution." << endl;
        }
     //   particleCloud.calcVelocityCorrection(p_rgh,rho,U,alpha1,alpha1);
        


        runTime.write();

        Info<< "ExecutionTime = " << runTime.elapsedCpuTime() << " s"
            << "  ClockTime = " << runTime.elapsedClockTime() << " s"
            << nl << endl;

        particleCloud.clockM().stop("Flow");
        particleCloud.clockM().stop("Global");
    }

    Info<< "End\n" << endl;

    return 0;
}


// ************************************************************************* //
