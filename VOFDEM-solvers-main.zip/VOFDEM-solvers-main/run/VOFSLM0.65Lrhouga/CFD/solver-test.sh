#!/bin/bash
#SBATCH -p paratera
#SBATCH -N 2
#SBATCH -n 48
source ~/soft/OpenFOAM/env.sh
rm -r pro*
blockMesh
decomposePar
yhrun -N 2 -n 48 VOFDEMSLMLrhouga -parallel #AA1 -parallel
#yhrun -p paratera -n 1 reconstructPar # -time 0.00256
#yhrun -p paratera -n 1 foamToVTK # -time 0.00256
