#!/bin/bash
#SBATCH -p paratera
#SBATCH -N 1
#SBATCH -n 1
source ~/soft/OpenFOAM/env.sh
rm -r pro*/*/l*
yhrun -p paratera -n 1 reconstructPar -time 0.000: 
yhrun -p paratera -n 1 foamToVTK -time 0.000:
rm -r VTK/s*
rm -r VTK/o*
                                                    
